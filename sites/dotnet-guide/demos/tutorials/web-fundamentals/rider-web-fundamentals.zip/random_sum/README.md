# Random Sum

When you click in the body, display a sum of random values.

## About

We need a simple web app that can show parts in pure NodeJS.
This is used first for the WebStorm Fundamentals videos starting at #8 for debugging.