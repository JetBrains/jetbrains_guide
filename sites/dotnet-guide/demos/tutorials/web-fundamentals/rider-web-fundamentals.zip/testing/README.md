From Jest examples: https://github.com/facebook/jest/tree/master/examples/getting-started
