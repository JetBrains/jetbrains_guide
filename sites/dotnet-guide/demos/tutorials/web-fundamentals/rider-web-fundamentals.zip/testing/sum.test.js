import {test} from '@jest/globals';

import {sum_three} from './sum';

test('sum three positives', () => {
    const [a, b, c] = [1, 2, 3];
    expect(sum_three(a, b, c)).toEqual(6);
});

test('add one negative and two positives', () => {
    const [a, b, c] = [-1, 2, 3];
    expect(sum_three(a, b, c)).toEqual(4);
});
