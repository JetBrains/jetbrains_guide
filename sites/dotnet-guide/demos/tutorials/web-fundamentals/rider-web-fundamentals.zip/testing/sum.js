// Return the sum of three numbers

export function sum_three(a, b, c) {
    /* Add 3 numbers */
    return a + b + c;
}
